-- Converte awc_clubs.logo da URL esterno a solo nome file,
-- coerente con la logica gia\ usata per le maglie.
-- DA LANCIARE SOLO DOPO scarica_loghi_club.ps1, verificando che i file ci siano.

UPDATE awc_clubs SET logo = CONCAT(club_id, '.png') WHERE logo LIKE 'http%';

-- verifica: nessuna riga deve restare con un URL
SELECT COUNT(*) AS url_residui FROM awc_clubs WHERE logo LIKE 'http%';
