﻿# Scarica le gif maglie 2010/2018 citate da historicalkits e non presenti in locale.
# Da lanciare nella radice del progetto: D:\PHP\htdocs\WC\mia-app
# Genera i file in resources\images\kits\{anno}\ , poi vanno committati.

$base = "https://www.historicalkits.co.uk"
$root = "resources\images\kits"
$ua   = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
$ok = 0; $ko = 0

# ---------- 2010 (30 file) ----------
$dir = Join-Path $root "2010"
if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }
$f = Join-Path $dir "argentina-2010-3.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/international/tournaments/fifa_world_cup_2010/images/argentina-2010-3.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO argentina-2010-3.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "argentina-2010-4.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/international/tournaments/fifa_world_cup_2010/images/argentina-2010-4.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO argentina-2010-4.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "argentina-2010-5.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/international/tournaments/fifa_world_cup_2010/images/argentina-2010-5.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO argentina-2010-5.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "argentina-2010-6.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/international/tournaments/fifa_world_cup_2010/images/argentina-2010-6.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO argentina-2010-6.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "brazil-2010-3.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/international/tournaments/fifa_world_cup_2010/images/brazil-2010-3.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO brazil-2010-3.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "cameroon-2010-4.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/international/tournaments/fifa_world_cup_2010/images/cameroon-2010-4.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO cameroon-2010-4.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "chile-2010-3.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/international/tournaments/fifa_world_cup_2010/images/chile-2010-3.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO chile-2010-3.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "chile-2010-4.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/international/tournaments/fifa_world_cup_2010/images/chile-2010-4.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO chile-2010-4.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "denmark-2010-3.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/international/tournaments/fifa_world_cup_2010/images/denmark-2010-3.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO denmark-2010-3.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "england-2010-2011-2-all-red.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/international/tournaments/fifa_world_cup_2010/images/england-2010-2011-2-all-red.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO england-2010-2011-2-all-red.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "france-2010-2.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/international/tournaments/fifa_world_cup_2010/images/france-2010-2.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO france-2010-2.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "france-2010-4.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/international/tournaments/fifa_world_cup_2010/images/france-2010-4.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO france-2010-4.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "germany-2010-3.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/international/tournaments/fifa_world_cup_2010/images/germany-2010-3.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO germany-2010-3.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "ghana-2010-2a.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/international/tournaments/fifa_world_cup_2010/images/ghana-2010-2a.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO ghana-2010-2a.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "italy-2010-3.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/international/tournaments/fifa_world_cup_2010/images/italy-2010-3.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO italy-2010-3.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "ivory-coast-2010-5.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/international/tournaments/fifa_world_cup_2010/images/ivory-coast-2010-5.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO ivory-coast-2010-5.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "japan-2010-3.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/international/tournaments/fifa_world_cup_2010/images/japan-2010-3.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO japan-2010-3.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "korea-north-2010-long-sleeves.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/international/tournaments/fifa_world_cup_2010/images/korea-north-2010-long-sleeves.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO korea-north-2010-long-sleeves.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "korea-south-2010-3.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/international/tournaments/fifa_world_cup_2010/images/korea-south-2010-3.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO korea-south-2010-3.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "mexico-2010-uruguay.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/international/tournaments/fifa_world_cup_2010/images/mexico-2010-uruguay.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO mexico-2010-uruguay.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "netherlands-2010-3.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/international/tournaments/fifa_world_cup_2010/images/netherlands-2010-3.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO netherlands-2010-3.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "nigeria-2010-long-sleeves.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/international/tournaments/fifa_world_cup_2010/images/nigeria-2010-long-sleeves.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO nigeria-2010-long-sleeves.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "paraguay-2010-3.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/international/tournaments/fifa_world_cup_2010/images/paraguay-2010-3.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO paraguay-2010-3.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "paraguay-2010-4.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/international/tournaments/fifa_world_cup_2010/images/paraguay-2010-4.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO paraguay-2010-4.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "portugal-2010-3.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/international/tournaments/fifa_world_cup_2010/images/portugal-2010-3.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO portugal-2010-3.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "serbia-2010-3.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/international/tournaments/fifa_world_cup_2010/images/serbia-2010-3.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO serbia-2010-3.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "serbia-2010-4.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/international/tournaments/fifa_world_cup_2010/images/serbia-2010-4.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO serbia-2010-4.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "spain-2010-3.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/international/tournaments/fifa_world_cup_2010/images/spain-2010-3.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO spain-2010-3.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "switzerland-2010-3.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/international/tournaments/fifa_world_cup_2010/images/switzerland-2010-3.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO switzerland-2010-3.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "uruguay-2010-3.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/international/tournaments/fifa_world_cup_2010/images/uruguay-2010-3.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO uruguay-2010-3.gif"; $ko++ } }
Start-Sleep -Milliseconds 350

# ---------- 2018 (42 file) ----------
$dir = Join-Path $root "2018"
if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }
$f = Join-Path $dir "argentina-2018-croatia.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/argentina-2018-croatia.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO argentina-2018-croatia.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "argentina-2018-iceland.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/argentina-2018-iceland.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO argentina-2018-iceland.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "australia-2018-denmark.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/australia-2018-denmark.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO australia-2018-denmark.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "australia-2018-france.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/australia-2018-france.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO australia-2018-france.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "australia-2018-peru.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/australia-2018-peru.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO australia-2018-peru.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "brazil-2018-costa-rica.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/brazil-2018-costa-rica.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO brazil-2018-costa-rica.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "colombia-2018-japan.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/colombia-2018-japan.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO colombia-2018-japan.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "colombia-2018-poland.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/colombia-2018-poland.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO colombia-2018-poland.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "costa-rica-2018-brazil.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/costa-rica-2018-brazil.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO costa-rica-2018-brazil.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "costa-rica-2018-serbia.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/costa-rica-2018-serbia.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO costa-rica-2018-serbia.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "croatia-2018-argentina.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/croatia-2018-argentina.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO croatia-2018-argentina.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "croatia-2018-denmark.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/croatia-2018-denmark.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO croatia-2018-denmark.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "croatia-2018-england.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/croatia-2018-england.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO croatia-2018-england.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "croatia-2018-france.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/croatia-2018-france.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO croatia-2018-france.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "croatia-2018-iceland.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/croatia-2018-iceland.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO croatia-2018-iceland.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "croatia-2018-nigeria.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/croatia-2018-nigeria.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO croatia-2018-nigeria.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "croatia-2018-russia.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/croatia-2018-russia.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO croatia-2018-russia.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "denmark-2018-peru.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/denmark-2018-peru.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO denmark-2018-peru.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "egypt-2018-uruguay.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/egypt-2018-uruguay.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO egypt-2018-uruguay.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "england-2018-croatia.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/england-2018-croatia.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO england-2018-croatia.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "england-2018-tunisia.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/england-2018-tunisia.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO england-2018-tunisia.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "france-2018-australia.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/france-2018-australia.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO france-2018-australia.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "france-2018-belgium.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/france-2018-belgium.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO france-2018-belgium.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "france-2018-peru.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/france-2018-peru.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO france-2018-peru.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "france-2018-uruguay.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/france-2018-uruguay.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO france-2018-uruguay.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "iceland-2018-argentina.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/iceland-2018-argentina.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO iceland-2018-argentina.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "iceland-2018-croatia.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/iceland-2018-croatia.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO iceland-2018-croatia.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "iceland-2018-nigeria.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/iceland-2018-nigeria.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO iceland-2018-nigeria.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "nigeria-2018-argentina.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/nigeria-2018-argentina.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO nigeria-2018-argentina.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "peru-2018-australia.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/peru-2018-australia.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO peru-2018-australia.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "peru-2018-denmark.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/peru-2018-denmark.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO peru-2018-denmark.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "peru-2018-france.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/peru-2018-france.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO peru-2018-france.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "poland-2018-japan.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/poland-2018-japan.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO poland-2018-japan.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "russia-2018-egypt.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/russia-2018-egypt.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO russia-2018-egypt.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "russia-2018-uruguay.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/russia-2018-uruguay.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO russia-2018-uruguay.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "serbia-2018-costa-rica.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/serbia-2018-costa-rica.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO serbia-2018-costa-rica.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "serbia-2018-switzerland.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/serbia-2018-switzerland.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO serbia-2018-switzerland.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "south-korea-2018-germany.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/south-korea-2018-germany.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO south-korea-2018-germany.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "south-korea-2018-mexico.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/south-korea-2018-mexico.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO south-korea-2018-mexico.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "south-korea-2018-sweden.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/south-korea-2018-sweden.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO south-korea-2018-sweden.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "switzerland-2018-costa-rica.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/switzerland-2018-costa-rica.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO switzerland-2018-costa-rica.gif"; $ko++ } }
Start-Sleep -Milliseconds 350
$f = Join-Path $dir "switzerland-2018-serbia.gif"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "$base/FIFA_World_Cup/2018/Kits/switzerland-2018-serbia.gif" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO switzerland-2018-serbia.gif"; $ko++ } }
Start-Sleep -Milliseconds 350

Write-Host "Scaricate/presenti: $ok - fallite: $ko (totale 72)"
