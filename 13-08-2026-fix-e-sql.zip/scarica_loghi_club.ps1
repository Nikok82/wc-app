﻿# Scarica in locale i loghi club oggi ospitati su cdn.soccerwiki.org.
# Da lanciare nella radice del progetto: D:\PHP\htdocs\WC\mia-app
# Destinazione: resources\images\clubs\{club_id}.png
# Dopo il download va lanciato converti_logo_club.sql (cambia la colonna in solo nome file).

$dir = "resources\images\clubs"
if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }
$ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
$ok = 0; $ko = 0

$f = Join-Path $dir "C-1.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/444.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-2.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/491.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-2"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-3.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/258.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-3"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-4.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/350.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-4"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-5.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/108.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-5"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-6.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/443.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-6"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-7.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/162.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-7"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-8.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/32.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-8"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-9.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/451.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-9"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-10.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/115.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-10"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-11.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/449.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-11"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-12.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/744.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-12"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-13.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/439.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-13"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-14.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1814.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-14"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-15.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/372.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-15"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-16.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/139.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-16"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-17.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1563.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-17"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-18.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/179.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-18"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-19.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/353.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-19"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-20.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/453.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-20"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-21.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/255.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-21"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-22.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/549.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-22"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-23.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1417.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-23"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-24.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/548.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-24"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-25.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/15.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-25"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-26.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2107.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-26"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-27.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/455.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-27"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-28.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/697.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-28"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-29.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/402.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-29"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-30.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/6847.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-30"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-31.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1572.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-31"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-32.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/547.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-32"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-33.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/528.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-33"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-34.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/689.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-34"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-35.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1514.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-35"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-36.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/391.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-36"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-37.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/518.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-37"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-38.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/192.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-38"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-39.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4260.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-39"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-40.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-40"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-41.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/399.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-41"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-42.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/88.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-42"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-43.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/680.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-43"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-44.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/539.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-44"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-45.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1084.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-45"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-46.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1520.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-46"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-47.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/75.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-47"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-48.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/349.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-48"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-49.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/338.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-49"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-50.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/421.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-50"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-51.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/681.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-51"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-52.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/380.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-52"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-53.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/393.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-53"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-54.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/77.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-54"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-55.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/201.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-55"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-56.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/368.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-56"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-57.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/793.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-57"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-58.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1624.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-58"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-59.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/390.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-59"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-60.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/369.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-60"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-61.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/817.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-61"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-62.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/329.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-62"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-63.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/85.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-63"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-64.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/243.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-64"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-65.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5228.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-65"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-66.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/50.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-66"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-67.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1187.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-67"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-68.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/862.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-68"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-69.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/72.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-69"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-70.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/110.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-70"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-71.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/37.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-71"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-72.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/174.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-72"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-73.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/429.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-73"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-74.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/336.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-74"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-75.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2116.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-75"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-76.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-76"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-77.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/54.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-77"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-78.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/758.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-78"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-79.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/366.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-79"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-80.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2606.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-80"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-81.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5288.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-81"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-82.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1109.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-82"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-83.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2012.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-83"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-84.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/125.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-84"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-85.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/96.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-85"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-86.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/370.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-86"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-87.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/218.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-87"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-88.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/535.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-88"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-89.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1255.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-89"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-90.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/417.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-90"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-91.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/398.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-91"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-92.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1549.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-92"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-93.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1508.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-93"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-94.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1157.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-94"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-95.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/406.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-95"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-96.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/359.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-96"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-97.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/941.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-97"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-98.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/358.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-98"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-99.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1181.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-99"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-100.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/504.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-100"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-101.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/691.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-101"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-102.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1252.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-102"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-103.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1259.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-103"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-104.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/734.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-104"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-105.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1610.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-105"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-106.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1213.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-106"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-107.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1656.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-107"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-108.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3288.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-108"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-109.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/392.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-109"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-110.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/401.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-110"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-111.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/109.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-111"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-112.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/332.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-112"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-113.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/340.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-113"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-114.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/98.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-114"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-115.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/411.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-115"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-116.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/76.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-116"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-117.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/55.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-117"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-118.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/328.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-118"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-119.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/168.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-119"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-120.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/172.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-120"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-121.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/40.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-121"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-122.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/872.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-122"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-123.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/750.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-123"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-124.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/395.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-124"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-125.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/481.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-125"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-126.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/44.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-126"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-127.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-127"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-128.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/49.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-128"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-129.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/294.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-129"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-130.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/163.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-130"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-131.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/52.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-131"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-132.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/304.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-132"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-133.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/140.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-133"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-134.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/602.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-134"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-135.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/265.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-135"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-136.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/627.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-136"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-137.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/288.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-137"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-138.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/628.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-138"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-139.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/11.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-139"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-140.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/9.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-140"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-141.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/625.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-141"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-142.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2002.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-142"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-143.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/432.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-143"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-144.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1313.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-144"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-145.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1323.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-145"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-146.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2668.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-146"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-147.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/355.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-147"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-148.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/344.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-148"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-149.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/310.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-149"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-150.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/27.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-150"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-151.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/522.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-151"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-152.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/373.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-152"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-153.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/571.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-153"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-154.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/123.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-154"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-155.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1188.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-155"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-156.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/312.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-156"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-157.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/656.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-157"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-158.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1730.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-158"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-159.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5289.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-159"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-160.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/334.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-160"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-161.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/629.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-161"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-162.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/459.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-162"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-163.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/343.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-163"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-164.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3593.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-164"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-165.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/997.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-165"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-166.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1416.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-166"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-167.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1455.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-167"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-168.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/798.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-168"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-169.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/311.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-169"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-170.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/520.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-170"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-172.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/556.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-172"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-173.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1316.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-173"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-174.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/6011.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-174"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-175.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/746.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-175"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-176.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/425.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-176"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-177.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-177"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-178.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/20.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-178"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-179.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/128.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-179"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-180.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/666.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-180"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-181.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/89.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-181"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-182.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/38.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-182"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-183.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/424.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-183"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-184.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/31.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-184"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-185.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/426.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-185"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-186.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/365.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-186"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-187.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/463.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-187"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-188.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4243.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-188"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-189.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5537.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-189"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-190.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1619.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-190"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-191.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1336.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-191"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-192.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/458.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-192"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-193.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/25.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-193"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-194.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/330.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-194"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-195.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/345.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-195"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-196.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3210.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-196"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-197.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/615.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-197"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-198.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/286.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-198"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-199.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/300.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-199"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-200.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/12.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-200"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-201.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/479.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-201"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-202.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3910.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-202"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-203.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/284.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-203"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-204.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/277.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-204"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-205.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/306.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-205"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-206.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1494.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-206"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-207.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/275.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-207"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-208.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/613.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-208"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-209.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/62.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-209"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-210.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1447.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-210"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-211.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1497.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-211"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-212.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/151.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-212"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-213.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/719.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-213"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-214.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/118.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-214"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-215.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/634.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-215"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-216.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/530.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-216"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-217.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1589.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-217"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-218.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/197.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-218"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-219.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/747.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-219"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-220.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/732.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-220"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-221.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/83.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-221"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-222.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/41.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-222"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-223.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/565.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-223"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-224.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/559.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-224"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-225.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/457.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-225"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-226.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2846.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-226"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-227.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/351.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-227"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-228.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1657.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-228"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-229.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4238.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-229"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-230.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/206.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-230"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-231.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5387.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-231"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-232.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/203.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-232"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-233.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/191.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-233"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-234.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/190.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-234"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-235.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/383.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-235"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-237.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4662.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-237"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-238.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/208.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-238"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-239.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/474.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-239"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-240.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/67.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-240"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-241.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/595.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-241"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-242.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1868.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-242"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-243.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/490.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-243"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-244.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/70.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-244"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-245.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/185.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-245"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-246.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/801.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-246"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-247.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/200.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-247"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-248.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/210.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-248"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-249.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/246.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-249"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-250.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/227.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-250"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-251.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1166.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-251"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-252.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/224.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-252"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-253.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1226.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-253"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-254.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/593.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-254"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-255.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/588.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-255"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-256.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/374.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-256"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-257.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/352.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-257"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-258.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/274.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-258"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-259.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/298.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-259"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-260.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/354.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-260"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-261.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1562.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-261"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-262.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1560.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-262"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-263.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/132.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-263"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-264.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/282.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-264"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-265.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/447.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-265"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-266.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/21.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-266"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-267.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/47.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-267"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-268.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/180.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-268"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-269.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/290.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-269"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-270.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/80.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-270"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-271.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/414.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-271"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-272.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/594.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-272"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-273.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/165.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-273"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-274.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/555.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-274"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-275.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/339.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-275"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-276.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/325.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-276"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-277.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/371.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-277"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-278.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/419.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-278"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-279.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/29.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-279"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-280.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/141.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-280"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-281.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/131.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-281"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-282.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1512.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-282"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-283.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/663.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-283"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-284.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1444.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-284"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-285.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/473.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-285"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-286.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/567.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-286"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-287.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1449.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-287"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-288.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/883.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-288"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-289.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5945.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-289"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-290.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/792.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-290"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-291.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/569.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-291"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-292.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/564.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-292"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-293.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/568.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-293"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-294.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1208.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-294"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-295.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2196_1360227604.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-295"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-296.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/521.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-296"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-297.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3400.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-297"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-298.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1612.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-298"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-300.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/525.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-300"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-301.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5497.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-301"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-302.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1816.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-302"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-303.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1699.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-303"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-304.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1217.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-304"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-305.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/685.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-305"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-306.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1401.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-306"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-307.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/259.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-307"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-308.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/665.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-308"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-309.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2036.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-309"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-310.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/684.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-310"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-311.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1324.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-311"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-312.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/356.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-312"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-313.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2650.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-313"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-314.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/51.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-314"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-315.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/563.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-315"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-316.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/6377.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-316"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-317.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2121.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-317"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-318.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/469.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-318"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-319.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/428.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-319"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-320.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1302.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-320"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-321.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1654.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-321"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-322.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2058.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-322"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-323.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/63.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-323"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-324.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/341.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-324"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-325.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/533.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-325"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-326.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/562.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-326"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-327.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1727.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-327"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-328.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/138.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-328"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-329.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/157.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-329"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-330.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/221.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-330"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-331.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3475.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-331"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-332.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5949.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-332"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-333.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/984.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-333"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-334.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1673.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-334"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-335.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/223.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-335"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-336.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/379.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-336"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-337.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5533.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-337"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-338.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/928.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-338"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-339.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1559.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-339"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-340.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1763.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-340"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-341.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2592.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-341"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-342.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2203.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-342"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-343.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/764.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-343"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-344.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/250.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-344"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-345.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2941.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-345"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-346.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/6226.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-346"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-347.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2407.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-347"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-348.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/605.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-348"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-349.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/327.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-349"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-350.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/6404.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-350"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-351.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/6405.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-351"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-352.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1298.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-352"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-353.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1671.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-353"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-354.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/512.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-354"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-355.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1529.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-355"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-356.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2934.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-356"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-357.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1077.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-357"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-358.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1522.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-358"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-359.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1364.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-359"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-360.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1363.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-360"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-361.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/834.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-361"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-362.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2552.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-362"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-363.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/45.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-363"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-365.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5058.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-365"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-366.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/189.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-366"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-367.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/6632.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-367"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-368.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/650.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-368"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-370.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1184.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-370"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-371.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1667.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-371"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-372.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1603.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-372"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-373.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1209.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-373"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-374.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/270.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-374"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-375.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1817.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-375"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-376.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1930.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-376"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-377.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1634.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-377"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-378.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/188.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-378"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-379.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1021.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-379"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-380.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/133.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-380"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-381.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/142.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-381"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-382.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/858.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-382"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-383.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1692.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-383"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-384.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/147.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-384"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-385.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1156.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-385"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-386.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1835.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-386"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-387.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/6122.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-387"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-389.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/677.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-389"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-390.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/573.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-390"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-391.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1370.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-391"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-392.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1694.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-392"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-393.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1525.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-393"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-394.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1033.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-394"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-395.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1641.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-395"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-396.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/626.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-396"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-397.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/153.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-397"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-398.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1072.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-398"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-399.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/496.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-399"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-400.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/333.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-400"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-401.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/575.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-401"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-402.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/263.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-402"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-403.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2978.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-403"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-404.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5277.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-404"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-405.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/148.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-405"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-406.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1347.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-406"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-407.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1102.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-407"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-408.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2335.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-408"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-409.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5886.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-409"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-410.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1791.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-410"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-411.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2046.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-411"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-412.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5436.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-412"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-413.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3674.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-413"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-414.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5437.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-414"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-416.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/912.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-416"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-417.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/441.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-417"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-418.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/100.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-418"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-420.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/287.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-420"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-421.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/283.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-421"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-422.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/335.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-422"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-423.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/285.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-423"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-424.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/307.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-424"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-425.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/107.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-425"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-426.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/538.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-426"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-427.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/711.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-427"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-428.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1420.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-428"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-429.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/445.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-429"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-430.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/295.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-430"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-431.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/450.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-431"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-432.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/272.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-432"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-433.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/465.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-433"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-434.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/375.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-434"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-435.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/807.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-435"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-436.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/661.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-436"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-437.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1663.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-437"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-438.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1229.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-438"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-439.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3877.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-439"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-440.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1421.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-440"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-441.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/446.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-441"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-442.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1448.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-442"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-443.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5074.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-443"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-444.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2873.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-444"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-445.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1359.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-445"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-446.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/972.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-446"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-447.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/979.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-447"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-448.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4600.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-448"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-449.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2133.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-449"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-450.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2184.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-450"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-451.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/660.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-451"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-452.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/173.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-452"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-453.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/278.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-453"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-455.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1151.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-455"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-458.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/124.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-458"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-459.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/331.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-459"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-460.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/135.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-460"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-461.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/205.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-461"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-463.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/733.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-463"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-464.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1346.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-464"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-465.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/790.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-465"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-467.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/795.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-467"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-468.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1445.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-468"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-469.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/788.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-469"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-470.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/78.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-470"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-471.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/18.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-471"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-472.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/36.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-472"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-473.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/422.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-473"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-474.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/87.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-474"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-475.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/464.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-475"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-476.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/651.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-476"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-477.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/317.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-477"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-478.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1465.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-478"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-479.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/918.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-479"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-480.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/99.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-480"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-481.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/143.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-481"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-482.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2365.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-482"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-483.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/561.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-483"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-484.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/558.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-484"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-485.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/508.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-485"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-486.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/638.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-486"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-488.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2837.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-488"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-489.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/385.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-489"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-490.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/751.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-490"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-491.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/315.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-491"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-492.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/6026.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-492"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-493.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/618.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-493"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-494.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/683.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-494"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-495.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/662.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-495"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-497.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4947.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-497"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-498.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1207.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-498"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-499.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4037.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-499"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-500.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1681.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-500"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-501.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2074.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-501"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-502.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/527.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-502"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-503.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2085.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-503"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-504.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/523.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-504"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-505.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/418.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-505"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-506.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/517.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-506"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-507.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1592.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-507"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-508.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/500.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-508"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-510.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2735.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-510"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-511.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3182.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-511"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-512.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/65.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-512"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-513.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/382.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-513"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-514.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/639.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-514"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-515.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1717.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-515"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-516.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/314.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-516"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-517.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/97.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-517"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-519.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/943.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-519"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-520.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/149.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-520"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-522.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/111.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-522"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-524.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/762.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-524"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-525.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1066.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-525"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-526.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5665.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-526"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-528.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1392.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-528"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-529.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1471.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-529"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-530.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/13.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-530"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-533.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1068.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-533"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-534.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1082.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-534"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-535.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/516.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-535"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-536.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/682.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-536"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-537.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2757.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-537"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-538.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/84.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-538"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-539.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/86.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-539"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-541.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1353.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-541"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-542.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/254.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-542"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-544.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/260.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-544"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-545.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2607.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-545"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-546.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/376.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-546"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-547.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/292.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-547"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-548.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1222.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-548"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-549.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/253.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-549"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-550.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1394.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-550"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-551.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3316.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-551"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-553.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/232.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-553"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-555.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/156.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-555"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-557.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/154.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-557"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-558.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3941.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-558"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-560.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1849.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-560"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-561.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1080.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-561"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-562.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2252.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-562"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-563.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/797.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-563"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-564.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/384.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-564"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-566.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/313.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-566"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-567.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/454.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-567"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-570.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1180.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-570"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-571.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/621.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-571"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-572.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2604.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-572"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-573.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1183.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-573"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-574.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1480.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-574"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-575.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/531.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-575"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-576.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2247.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-576"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-577.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/898.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-577"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-579.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/347.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-579"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-580.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1140.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-580"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-581.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/468.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-581"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-582.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1901_1360704502.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-582"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-583.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/420.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-583"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-584.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/361.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-584"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-585.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1606.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-585"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-586.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1435.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-586"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-587.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/499.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-587"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-588.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1058.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-588"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-589.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5084.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-589"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-590.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1152.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-590"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-592.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/105.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-592"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-593.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2171.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-593"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-595.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/177.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-595"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-596.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1153.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-596"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-598.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1767.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-598"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-599.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1731.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-599"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-600.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/381.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-600"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-601.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/146.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-601"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-602.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1079.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-602"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-603.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1804.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-603"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-604.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1085.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-604"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-605.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/679.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-605"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-607.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1083.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-607"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-609.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/554.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-609"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-611.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2072.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-611"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-613.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1212.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-613"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-614.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/905.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-614"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-615.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1714.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-615"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-616.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5842.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-616"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-617.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/975.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-617"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-618.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4123.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-618"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-619.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/364.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-619"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-621.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1317.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-621"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-622.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1412.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-622"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-623.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/901.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-623"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-624.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3386.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-624"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-626.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4601.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-626"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-627.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/316.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-627"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-628.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/906.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-628"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-629.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/619.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-629"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-630.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1078.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-630"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-631.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1467.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-631"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-632.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1075.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-632"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-633.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4760.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-633"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-634.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2751.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-634"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-636.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/308.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-636"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-637.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/566.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-637"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-638.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1288.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-638"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-639.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/61.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-639"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-640.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/752.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-640"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-641.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/363.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-641"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-642.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/362.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-642"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-643.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/916.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-643"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-646.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/386.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-646"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-647.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/415.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-647"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-648.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/534.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-648"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-649.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/506.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-649"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-650.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/683.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-650"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-652.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1498.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-652"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-653.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/466.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-653"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-654.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5279.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-654"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-655.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/117.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-655"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-657.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/658.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-657"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-658.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/886.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-658"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-659.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/209.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-659"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-661.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/648_1227016450.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-661"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-662.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/440.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-662"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-663.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1649.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-663"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-665.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1609.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-665"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-667.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/101.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-667"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-668.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1850.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-668"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-669.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1517.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-669"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-670.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1434_1348530757.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-670"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-672.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/800.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-672"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-673.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/796.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-673"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-674.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/244.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-674"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-675.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1542.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-675"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-677.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2738.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-677"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-678.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2966.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-678"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-679.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2200.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-679"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-681.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1659_1293037425.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-681"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-682.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3217.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-682"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-683.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2062.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-683"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-684.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/932.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-684"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-685.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/434.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-685"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-686.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1627.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-686"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-687.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/460.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-687"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-688.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2042.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-688"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-689.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/214.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-689"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-690.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/113.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-690"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-691.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/360.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-691"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-692.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/676.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-692"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-694.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/7.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-694"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-695.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1086.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-695"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-697.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/546.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-697"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-699.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1008.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-699"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-700.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1003.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-700"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-701.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/6845.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-701"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-702.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2523.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-702"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-704.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/269.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-704"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-705.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/624.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-705"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-707.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/601.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-707"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-710.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/604.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-710"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-711.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1059.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-711"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-712.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/498.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-712"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-713.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/536.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-713"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-714.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1065.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-714"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-715.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/126.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-715"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-717.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1685.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-717"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-718.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/323.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-718"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-719.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1115.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-719"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-720.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1608.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-720"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-721.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/112.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-721"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-722.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/956.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-722"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-723.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/320.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-723"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-724.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/475.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-724"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-725.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/104.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-725"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-728.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/187.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-728"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-729.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1422.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-729"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-730.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-730"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-731.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/591.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-731"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-732.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/532.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-732"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-733.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/408.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-733"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-735.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/176.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-735"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-736.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/947.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-736"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-737.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/247.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-737"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-738.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1391_1349510404.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-738"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-739.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1216_1347868802.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-739"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-740.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1440_1354423524.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-740"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-741.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/199.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-741"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-742.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1393.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-742"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-744.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/511.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-744"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-745.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/405.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-745"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-746.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/267.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-746"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-747.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/911.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-747"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-748.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1886.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-748"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-749.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2143.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-749"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-750.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/60.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-750"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-751.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1982.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-751"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-752.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2114.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-752"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-755.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/261.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-755"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-756.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1173.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-756"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-757.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/103.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-757"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-759.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2202.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-759"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-762.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2517.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-762"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-764.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/550.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-764"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-768.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1355.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-768"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-769.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/513.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-769"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-770.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/390.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-770"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-772.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/122.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-772"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-774.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/978.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-774"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-775.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1495_1277178412.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-775"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-777.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/655.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-777"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-778.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/734.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-778"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-779.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/659.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-779"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-780.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/656.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-780"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-781.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/267.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-781"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-784.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/393.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-784"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-785.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/385.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-785"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-786.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/256.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-786"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-787.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5556.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-787"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-789.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/352.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-789"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-790.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/539.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-790"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-792.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/918.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-792"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-793.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/650.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-793"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-795.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/651.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-795"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-796.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/71.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-796"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-797.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/278.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-797"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-798.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/272.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-798"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-800.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/200.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-800"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-802.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/654.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-802"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-803.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/451.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-803"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-804.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/443.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-804"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-805.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/447.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-805"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-806.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/673.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-806"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-808.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/471.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-808"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-809.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/542.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-809"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-810.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/524.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-810"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-811.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/370.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-811"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-812.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/470.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-812"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-813.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/745.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-813"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-814.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/33.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-814"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-815.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/89.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-815"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-817.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/503.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-817"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-818.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/461.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-818"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-819.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2838.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-819"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-820.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2304.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-820"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-821.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/559.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-821"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-822.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/644.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-822"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-823.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/139.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-823"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-824.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/344.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-824"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-825.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/341.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-825"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-827.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/335.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-827"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-828.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/338.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-828"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-829.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/330.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-829"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-830.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5695.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-830"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-832.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/318.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-832"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-833.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/432.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-833"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-835.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/326.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-835"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-836.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/595.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-836"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-837.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/653.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-837"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-838.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/380.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-838"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-839.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/945.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-839"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-840.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/351.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-840"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-841.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/233.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-841"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-842.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3219.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-842"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-845.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3720.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-845"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-846.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/249.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-846"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-847.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2837.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-847"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-849.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/227.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-849"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-850.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/238.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-850"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-851.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/37.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-851"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-852.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/522.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-852"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-853.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/317.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-853"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-855.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/240.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-855"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-856.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/684.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-856"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-859.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1217.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-859"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-862.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/629.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-862"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-863.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/685.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-863"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-864.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1222.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-864"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-866.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/648_1227016450.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-866"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-867.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/439.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-867"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-869.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/441.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-869"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-871.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/810.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-871"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-872.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/359.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-872"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-873.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/369.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-873"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-875.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/116.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-875"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-876.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/835.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-876"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-877.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1392.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-877"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-879.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1221.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-879"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-882.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/117.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-882"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-884.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/396.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-884"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-885.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/438.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-885"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-886.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/472.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-886"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-888.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/366.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-888"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-890.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/500.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-890"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-891.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/528.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-891"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-892.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/320.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-892"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-893.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/506.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-893"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-895.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/680.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-895"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-899.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/234.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-899"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-900.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/395.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-900"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-901.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5523.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-901"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-903.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/719.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-903"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-905.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/434.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-905"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-906.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/331.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-906"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-909.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5722.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-909"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-916.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/627.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-916"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-918.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/6851.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-918"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-921.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/801.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-921"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-922.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/345.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-922"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-923.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/490.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-923"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-924.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2196_1360227604.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-924"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-926.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/313.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-926"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-927.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/512.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-927"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-928.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/796.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-928"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-931.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1100.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-931"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-933.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/610.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-933"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-934.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/467.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-934"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-935.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/342.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-935"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-936.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/321.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-936"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-938.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4313.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-938"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-939.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/119.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-939"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-940.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5662.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-940"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-941.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/727.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-941"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-942.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/416.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-942"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-945.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1004.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-945"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-946.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/954.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-946"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-948.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/141.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-948"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-949.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/390.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-949"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-950.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/163.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-950"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-951.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/109.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-951"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-952.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/338.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-952"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-955.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/118.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-955"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-956.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/162.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-956"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-957.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1065.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-957"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-958.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1153.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-958"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-959.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1066.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-959"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-960.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/644.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-960"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-961.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1677.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-961"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-966.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1518.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-966"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-969.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/661.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-969"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-970.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/662.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-970"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-972.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/350.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-972"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-973.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-973"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-974.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/41.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-974"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-975.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/349.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-975"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-977.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/511.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-977"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-979.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1849.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-979"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-980.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/386.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-980"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-981.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/864.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-981"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-983.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1073.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-983"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-984.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/224.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-984"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-986.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/148.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-986"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-987.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/219.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-987"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-988.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/676.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-988"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-992.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/353.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-992"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-993.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1059.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-993"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-994.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2449.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-994"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-996.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/552.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-996"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-997.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1084.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-997"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-998.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/27.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-998"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-999.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/199.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-999"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1001.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/455.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1001"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1002.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/98.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1002"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1003.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/7108.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1003"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1004.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3211.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1004"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1005.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/153.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1005"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1006.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/798.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1006"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1007.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/70.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1007"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1008.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/335.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1008"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1009.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/325.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1009"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1010.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/156.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1010"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1011.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/414.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1011"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1012.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/40.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1012"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1013.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1445.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1013"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1014.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/38.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1014"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1015.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/20.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1015"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1016.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/25.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1016"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1017.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/665.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1017"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1018.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/627.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1018"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1019.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/172.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1019"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1021.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/85.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1021"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1022.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/72.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1022"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1023.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/751.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1023"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1024.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/167.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1024"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1025.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/204.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1025"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1028.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/26.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1028"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1029.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1344.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1029"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1030.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/474.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1030"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1031.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1058.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1031"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1032.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4581.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1032"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1034.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/403.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1034"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1035.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/370.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1035"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1036.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/132.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1036"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1037.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/366.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1037"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1038.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/133.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1038"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1040.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/112.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1040"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1041.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/374.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1041"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1042.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/938.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1042"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1043.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/667.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1043"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1044.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/118.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1044"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1045.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/443.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1045"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1046.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/447.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1046"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1047.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/158.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1047"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1048.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1180.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1048"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1050.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/173.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1050"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1051.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/667.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1051"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1052.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/453.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1052"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1053.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/212.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1053"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1056.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/254.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1056"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1057.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/264.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1057"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1060.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/568.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1060"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1061.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/797.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1061"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1062.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1613.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1062"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1063.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4455.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1063"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1065.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2600.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1065"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1067.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/400.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1067"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1068.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3207.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1068"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1069.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5678.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1069"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1070.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/357.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1070"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1071.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1691.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1071"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1072.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2539.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1072"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1073.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/857.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1073"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1077.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/219.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1077"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1078.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/364.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1078"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1079.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/971.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1079"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1080.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/925.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1080"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1081.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/970.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1081"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1086.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1002.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1086"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1087.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3148.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1087"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1089.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/389.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1089"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1090.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3171.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1090"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1091.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/204.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1091"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1094.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/273.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1094"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1095.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/596.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1095"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1096.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1801_1360874108.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1096"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1097.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/678.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1097"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1101.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1972.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1101"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1103.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/170.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1103"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1104.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/169.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1104"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1106.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/917.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1106"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1107.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1276.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1107"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1108.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/378.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1108"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1109.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/167.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1109"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1111.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5598.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1111"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1112.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1927.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1112"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1113.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2955.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1113"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1114.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/281.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1114"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1115.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1700.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1115"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1117.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2493.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1117"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1119.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2141.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1119"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1121.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2136.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1121"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1122.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2352.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1122"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1124.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4834.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1124"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1126.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/620.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1126"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1127.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1286.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1127"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1128.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1890.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1128"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1131.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/387.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1131"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1132.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/806.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1132"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1133.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1337.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1133"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1134.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2722.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1134"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1135.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4865.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1135"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1136.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/241.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1136"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1138.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/6064.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1138"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1139.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1953.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1139"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1140.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/394.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1140"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1142.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2154_1358043310.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1142"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1143.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/471.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1143"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1145.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1238.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1145"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1146.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1413.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1146"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1147.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1407.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1147"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1148.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1845.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1148"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1149.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1356.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1149"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1150.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5075.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1150"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1151.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/682.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1151"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1154.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/866.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1154"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1155.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1189.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1155"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1157.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1249.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1157"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1158.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2217.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1158"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1160.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/372.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1160"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1161.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/194.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1161"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1162.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1281.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1162"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1166.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1023.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1166"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1168.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1794_1326877208.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1168"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1169.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/81.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1169"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1170.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/57.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1170"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1171.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/693.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1171"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1172.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/698.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1172"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1173.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3644.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1173"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1174.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3644.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1174"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1176.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/556.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1176"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1181.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1290.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1181"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1183.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1841.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1183"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1184.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4545.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1184"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1185.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1171.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1185"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1186.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1679.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1186"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1187.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5130.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1187"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1188.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/753.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1188"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1193.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3347.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1193"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1198.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2702.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1198"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1201.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1507.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1201"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1203.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/324.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1203"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1204.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4692.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1204"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1207.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4223.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1207"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1208.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1119.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1208"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1209.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/254.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1209"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1213.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/675.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1213"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1217.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1538.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1217"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1219.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1536.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1219"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1220.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1431.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1220"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1223.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/623.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1223"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1224.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/216.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1224"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1225.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1387.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1225"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1228.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/55.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1228"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1229.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3389.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1229"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1230.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/270.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1230"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1231.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1305.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1231"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1232.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/961.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1232"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1233.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2596.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1233"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1234.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/958.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1234"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1235.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/957.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1235"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1238.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/477.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1238"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1245.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1363.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1245"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1247.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/6012.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1247"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1249.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1986.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1249"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1252.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1093.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1252"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1255.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1035.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1255"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1256.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4542.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1256"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1261.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4327.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1261"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1263.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5594.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1263"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1264.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1015.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1264"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1266.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/799.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1266"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1267.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1014.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1267"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1268.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1020.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1268"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1270.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1308.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1270"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1271.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1010.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1271"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1272.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1338.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1272"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1273.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1120.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1273"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1274.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2273.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1274"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1276.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1746.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1276"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1279.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/56.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1279"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1281.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1038.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1281"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1283.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/58.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1283"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1284.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/487.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1284"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1285.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1034.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1285"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1286.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2091_1349816384.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1286"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1287.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/198.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1287"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1290.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1185.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1290"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1291.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/921.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1291"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1292.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2672.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1292"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1294.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2823.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1294"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1295.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/6108.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1295"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1298.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/31.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1298"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1299.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1303.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1299"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1300.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1898.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1300"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1302.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2885.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1302"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1303.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/6152.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1303"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1304.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/509.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1304"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1307.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1074.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1307"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1308.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4212.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1308"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1309.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3326.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1309"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1313.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/742.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1313"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1314.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/637.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1314"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1316.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/925.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1316"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1317.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/976.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1317"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1318.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1599.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1318"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1319.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/481.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1319"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1320.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/482.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1320"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1325.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2867.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1325"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1328.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1017.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1328"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1330.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2460.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1330"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1331.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5081.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1331"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1332.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1186.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1332"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1333.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/804.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1333"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1337.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1716.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1337"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1339.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1609.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1339"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1341.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1649.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1341"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1343.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2615.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1343"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1345.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/17.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1345"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1346.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/10.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1346"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1347.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1199.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1347"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1348.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/303.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1348"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1349.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5991.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1349"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1350.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4502.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1350"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1353.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/6172.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1353"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1355.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/6021.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1355"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1357.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4042.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1357"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1359.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/6529.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1359"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1361.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/761.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1361"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1363.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1311.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1363"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1366.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3625.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1366"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1368.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1540.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1368"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1369.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2950.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1369"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1373.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/539.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1373"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1375.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/6075.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1375"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1376.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/686.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1376"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1383.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1397_1264693898.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1383"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1386.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1394.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1386"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1387.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1474.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1387"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1388.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/509.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1388"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1389.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/901.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1389"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1390.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/761.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1390"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1392.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/784.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1392"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1393.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2324.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1393"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1394.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/410.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1394"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1396.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3622.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1396"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1401.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4487.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1401"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1402.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4410.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1402"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1404.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4973.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1404"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1406.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4490.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1406"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1407.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/978.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1407"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1408.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1552.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1408"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1410.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1205.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1410"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1411.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3208.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1411"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1418.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1584.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1418"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1419.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2995.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1419"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1420.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1729_1326963607.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1420"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1422.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/920.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1422"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1423.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1240.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1423"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1424.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1097.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1424"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1426.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1669.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1426"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1427.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/956.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1427"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1429.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1254.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1429"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1431.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/6432.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1431"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1434.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/6431.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1434"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1435.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1311.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1435"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1437.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1557.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1437"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1439.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1543_1253604786.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1439"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1440.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2869.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1440"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1443.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/671.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1443"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1444.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/756.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1444"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1445.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1011.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1445"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1446.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/835.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1446"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1447.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1492.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1447"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1448.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2398.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1448"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1454.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1931.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1454"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1455.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3188.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1455"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1456.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1286.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1456"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1457.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/822.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1457"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1458.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/831.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1458"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1459.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2199.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1459"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1462.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/6.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1462"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1464.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1585.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1464"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1468.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1095.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1468"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1469.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/144.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1469"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1471.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2815.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1471"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1473.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/229.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1473"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1474.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/969.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1474"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1479.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/941.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1479"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1481.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1552.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1481"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1482.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1291.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1482"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1483.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/375.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1483"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1484.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/376.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1484"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1485.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1095.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1485"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1486.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1854.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1486"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1489.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/615.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1489"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1490.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/912.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1490"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1491.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/913.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1491"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1492.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/917.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1492"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1493.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/619.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1493"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1494.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/906.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1494"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1495.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/618.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1495"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1497.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/750.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1497"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1498.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/486.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1498"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1499.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/406.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1499"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1500.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/386.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1500"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1501.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/387.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1501"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1502.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3861.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1502"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1503.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/362.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1503"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1504.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/364.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1504"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1505.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/974.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1505"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1506.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/977.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1506"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1507.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/109.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1507"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1511.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4542.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1511"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1513.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/535.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1513"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1515.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/383.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1515"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1517.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/368.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1517"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1518.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1173.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1518"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1519.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5130.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1519"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1521.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/369.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1521"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1522.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/753.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1522"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1523.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/814.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1523"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1524.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1316.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1524"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1525.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1421.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1525"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1527.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/440.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1527"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1529.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1020.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1529"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1530.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1017.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1530"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1531.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1014.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1531"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1532.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1010.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1532"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1533.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1023.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1533"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1536.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/71.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1536"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1537.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/36.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1537"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1538.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/84.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1538"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1542.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/954.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1542"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1544.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/361.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1544"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1545.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/6078.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1545"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1546.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/957.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1546"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1547.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/955.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1547"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1548.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2596.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1548"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1550.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/400.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1550"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1554.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/34.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1554"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1555.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/73.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1555"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1556.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/30.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1556"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1557.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/48.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1557"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1558.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1034.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1558"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1559.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1038.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1559"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1560.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1173.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1560"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1563.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/285.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1563"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1564.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/339.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1564"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1565.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5594.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1565"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1566.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/434.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1566"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1567.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/310.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1567"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1568.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/6038.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1568"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1569.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1202.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1569"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1570.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/613.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1570"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1571.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/642.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1571"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1572.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/61.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1572"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1573.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/424.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1573"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1574.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/670.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1574"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1575.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1208.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1575"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1576.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/856.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1576"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1577.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/675.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1577"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1578.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3572.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1578"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1579.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3765.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1579"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1580.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/18.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1580"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1581.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/60.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1581"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1582.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1016.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1582"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1583.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/440.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1583"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1585.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1712.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1585"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1586.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/7.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1586"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1587.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4882.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1587"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1588.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/357.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1588"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1590.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1275.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1590"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1592.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/346.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1592"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1594.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1180.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1594"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1595.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/450.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1595"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1599.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1661_1360788855.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1599"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1600.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/398.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1600"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1601.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1288.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1601"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1602.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3563.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1602"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1603.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/511.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1603"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1610.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/369.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1610"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1611.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/889.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1611"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1614.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/761.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1614"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1615.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/645.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1615"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1616.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/769.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1616"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1617.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/643.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1617"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1618.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/36.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1618"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1619.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/45.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1619"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1620.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1733_1326877210.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1620"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1622.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5010.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1622"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1625.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4624.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1625"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1626.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2606.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1626"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1629.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/307.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1629"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1630.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1730.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1630"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1631.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1189.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1631"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1633.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1274.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1633"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1634.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1732_1361658743.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1634"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1635.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2961.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1635"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1638.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1180.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1638"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1642.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1844.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1642"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1653.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1781.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1653"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1654.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/671.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1654"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1655.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2635.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1655"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1656.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/130.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1656"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1657.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/654.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1657"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1660.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1413.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1660"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1667.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/857.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1667"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1670.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4482.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1670"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1671.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1614.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1671"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1673.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/671.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1673"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1674.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4142.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1674"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1675.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1729_1326963607.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1675"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1676.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3764.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1676"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1677.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/542.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1677"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1678.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/368.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1678"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1680.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2320.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1680"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1681.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1218.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1681"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1682.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/343.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1682"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1688.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/432.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1688"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1691.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1746.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1691"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1693.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4825.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1693"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1701.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1437.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1701"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1702.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4709.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1702"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1703.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/388.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1703"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1704.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2838.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1704"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1708.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/738.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1708"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1709.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/649.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1709"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1710.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1899.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1710"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1711.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1304.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1711"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1716.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/467.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1716"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1719.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3917.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1719"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1720.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/468.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1720"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1722.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/693.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1722"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1724.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/593.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1724"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1725.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/356.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1725"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1729.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/179.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1729"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1731.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/195.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1731"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1733.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/186.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1733"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1752.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4739.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1752"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1754.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1437.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1754"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1757.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/388.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1757"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1765.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1812.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1765"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1767.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/669.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1767"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1768.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1970.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1768"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1770.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1883.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1770"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1772.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3207.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1772"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1773.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1692.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1773"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1781.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4273.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1781"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1784.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2311.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1784"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1785.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2580.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1785"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1790.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3588.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1790"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1791.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2580.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1791"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1792.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1979.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1792"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1793.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/266.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1793"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1794.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3688.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1794"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1795.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/926.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1795"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1798.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1181.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1798"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1802.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1387.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1802"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1805.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3166.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1805"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1817.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4318.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1817"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1818.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4523.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1818"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1819.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3159.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1819"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1820.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5072.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1820"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1821.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/600.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1821"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1822.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/969.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1822"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1823.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3619.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1823"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1824.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/973.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1824"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1826.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1091.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1826"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1827.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/714.jpg" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1827"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1829.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5594.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1829"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1833.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/343.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1833"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1834.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1883.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1834"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1836.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/439.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1836"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1842.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/3204.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1842"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1843.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4370.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1843"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1845.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5056.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1845"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1846.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/945.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1846"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1849.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/947.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1849"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1850.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/622.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1850"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1851.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/621.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1851"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1858.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/5893.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1858"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1859.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2418.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1859"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1861.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/830.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1861"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1862.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1890.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1862"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1866.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/375.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1866"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1867.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1094.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1867"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1868.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1425.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1868"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1869.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/1011.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1869"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1870.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/921.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1870"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1871.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/353.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1871"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1872.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/2980.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1872"; $ko++ } }
Start-Sleep -Milliseconds 250
$f = Join-Path $dir "C-1875.png"
if (Test-Path $f) { $ok++ } else { try { Invoke-WebRequest -Uri "https://cdn.soccerwiki.org/images/logos/clubs/4277.png" -OutFile $f -UserAgent $ua -TimeoutSec 30; $ok++ } catch { Write-Host "KO C-1875"; $ko++ } }
Start-Sleep -Milliseconds 250

Write-Host "Scaricati/presenti: $ok - falliti: $ko (totale 1342)"
